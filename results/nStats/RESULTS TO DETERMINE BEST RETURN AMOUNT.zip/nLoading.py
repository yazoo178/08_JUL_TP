import re
import pylab as p
import numpy as np
import matplotlib.pyplot as plt
import re


resultFile = open("outputFile.txt", "r")
recals = []
pres = []
mean = []

for line in resultFile.readlines():
    vals = line.split(",")
    pres.append(float(vals[4].strip()))
    recals.append(float(vals[5].strip()))
    mean.append(float(vals[6].replace(')', '').strip()))
        





#plt.show()


#X = [x/100 for x in range(500, 5000, 10)]
X = range(0, 100)
#Y = averageRecalls
#Y2 = averagePres
p.plot(X,recals, label = "Average Recall")
p.plot(X,pres, label = "Average Precision")
p.plot(X, mean, label= "Harmonic Mean")
#p.xlabel("Permitted % difference between vector simularity rates", fontsize=13)
p.xlabel("Number of documents returned", fontsize=13)
p.ylabel('Rate (0-1)', fontsize=13)
p.legend( loc='lower right')
#p.suptitle("The F-Measure rate for increasing the percentage before cut off (-s-m-tf:n-idf:t)", fontsize=14)
p.suptitle("How the number of documents returned affects the recall, precision and harmonic mean", fontsize=14)
p.show()













