import re
import pylab as p
import numpy as np
import matplotlib.pyplot as plt
import re


resultFile = open("outputFile.txt", "r")
recals = []
pres = []
mean = []

for line in resultFile.readlines():
    vals = line.split(",")
    pres.append(float(vals[4].strip()))
    recals.append(float(vals[5].strip()))
    mean.append(float(vals[6].replace(')', '').strip()))
        





#plt.show()

print(len(mean))
X = [x/100 for x in range(480, 5000, 10)]
#X = range(0, 100)
#Y = averageRecalls
#Y2 = averagePres
p.plot(X,recals, label = "Average Recall")
p.plot(X,pres, label = "Average Precision")
p.plot(X, mean, label= "Harmonic Mean")
p.xlabel("Permitted % difference between vector simularity rates", fontsize=13)
#p.xlabel("Number of documents returned", fontsize=13)
p.ylabel('Rate (0-1)', fontsize=13)
p.legend( loc='lower right')
p.suptitle("Rate for increasing the percentage before cut off (-s-m-tf:n-idf:t)", fontsize=14)
p.show()













